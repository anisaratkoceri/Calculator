namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double op1 = 0.00;
        double op2 = 0.00;
        string operation = string.Empty;

        public void button_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (string.IsNullOrEmpty(btn?.Tag?.ToString()))
            {
                outputArea.Text = "";
                inputArea.Text += btn?.Text;
                return;
            }

            switch(btn?.Tag?.ToString()) 
            {
                case "+":
                    {
                        op1 = double.Parse(inputArea.Text);
                        operation = "+";
                        inputArea.Text = "";
                        break;
                    }
                case "=": 
                    {
                        op2 = double.Parse(inputArea.Text);
                        inputArea.Text = "";
                        outputArea.Text = $"{op1} {operation} {op2} = {GetResult(operation)}";
                        op1 = 0.00;
                        op2 = 0.00;
                        operation = string.Empty;
                        break;
                    }
            }
        }

        public double GetResult(string operation)
        {
            switch (operation)
            {
                case "+": { return op1 + op2; }
                default: { return 0.00; }
            }
        }
    }
}
